﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Employees : Form
    {
        Functions con;
        int key = 0;
        public Employees()
        {
            InitializeComponent();
            con = new Functions();
            ShowEmployee();
        }
        private void ShowEmployee()
        {
            string Query = "select * from EmployeesTbl";
            EmployeeDGV.DataSource = con.GetData(Query);
        }
        private void ResetColumns()
        {
            EmpNameTb.Text = "";
            EmpSalTb.Text = "";
            EmpAgeTb.Text = "";
            EmpnoTb.Text = "";
            key = 0;
        }

        private void EmployeeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (EmployeeDGV.SelectedRows.Count > 0)
                {
                    EmpNameTb.Text = EmployeeDGV.SelectedRows[0].Cells["EmpName"].Value.ToString();
                    EmpSalTb.Text = EmployeeDGV.SelectedRows[0].Cells["EmpSal"].Value.ToString();
                    EmpAgeTb.Text = EmployeeDGV.SelectedRows[0].Cells["EmpAge"].Value.ToString();
                    EmpnoTb.Text = EmployeeDGV.SelectedRows[0].Cells["Empno"].Value.ToString();

                    key = Convert.ToInt32(EmployeeDGV.SelectedRows[0].Cells[0].Value.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Medicinebtn_Click(object sender, EventArgs e)
        {
            Medicine ob = new Medicine();
            ob.Show();
            this.Close();
        }

        private void CompanyBtn_Click(object sender, EventArgs e)
        {
            Company ob = new Company();
            ob.Show();
            this.Close();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer ob = new Customer();
            ob.Show();
            this.Close();
        }

        private void DoctorBtn_Click(object sender, EventArgs e)
        {
            Doctor ob = new Doctor();
            ob.Show();
            this.Close();
        }

        private void BillBtn_Click(object sender, EventArgs e)
        {
            Bill ob = new Bill();
            ob.Show();
            this.Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (EmpNameTb.Text == "" || EmpnoTb.Text == "" || EmpSalTb.Text == "" || EmpAgeTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string EmpName = EmpNameTb.Text;
                    string Empno = EmpnoTb.Text;
                    string EmpAge = EmpAgeTb.Text;
                    int EmpSal = Convert.ToInt32(EmpSalTb.Text);

                    string Query = "Insert into EmployeesTbl (EmpName,EmpSal,EmpAge, Empno)" +
                                   "Values (@EmpName,@EmpSal,@EmpAge, @Empno)";

                    con.SetData(Query, new { EmpName, EmpSal, EmpAge, Empno });
                    ShowEmployee();
                    MessageBox.Show("Employee Added");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while Adding the Employee: " + ex.Message);
                }
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (EmpNameTb.Text == "" || EmpnoTb.Text == "" || EmpSalTb.Text == "" || EmpAgeTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string EmpName = EmpNameTb.Text;
                    string Empno = EmpnoTb.Text;
                    string EmpAge = EmpAgeTb.Text;
                    int EmpSal = Convert.ToInt32(EmpSalTb.Text);

                    string Query = "Update EmployeesTbl " +
                        "Set EmpName=@EmpName, EmpSal=@EmpSal, EmpAge=@EmpAge, Empno=@Empno " +
                        "Where EmpId=@EmpId";

                    con.SetData(Query, new { EmpName, EmpSal, EmpAge, Empno, EmpId = key });
                    ShowEmployee();
                    MessageBox.Show("Employee Updated");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while Updating the Employee: " + ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Select a Employee !!");
            }
            else
            {
                try
                {
                    string Query = "Delete from EmployeesTbl Where EmpId = @EmpId";
                    con.SetData(Query, new { EmpId = key });
                    ShowEmployee();
                    MessageBox.Show("Employee Deleted");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}