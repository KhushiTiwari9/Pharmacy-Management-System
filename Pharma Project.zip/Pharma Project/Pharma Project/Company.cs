﻿using Pharma_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Company : Form
    {
        Functions con;
        public Company()
        {
            InitializeComponent();
            con = new Functions();
            ShowCompany();
        }
        private void ShowCompany()
        {
            string Query = "select * from CompanyTbl";
            ComDGV.DataSource = con.GetData(Query);
        }

        private void ResetColumns()
        {
            ComNameTb.Text = "";
            ComNoTb.Text = "";
            ComAddrTb.Text = "";
            Key = 0;
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if ( ComNameTb.Text == "" || ComNoTb.Text == "" || ComAddrTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string ComName = ComNameTb.Text;
                    double ComNo = Convert.ToDouble(ComNoTb.Text);
                    string ComAddr = ComAddrTb.Text;
                    string Query = "Insert into CompanyTbl (ComName,ComNo, ComAddr) values(@ComName, @ComNo, @ComAddr)";
                    con.SetData(Query, new { ComName, ComNo, ComAddr });

                    ShowCompany();

                    MessageBox.Show("Company Added");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }
        int Key = 0;
        private void ComDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (ComDGV.SelectedRows.Count > 0)
                {
                    ComNameTb.Text = ComDGV.SelectedRows[0].Cells["ComName"].Value.ToString();
                    ComNoTb.Text = ComDGV.SelectedRows[0].Cells["ComNo"].Value.ToString();
                    ComAddrTb.Text = ComDGV.SelectedRows[0].Cells["ComAddr"].Value.ToString();

                    Key = Convert.ToInt32(ComDGV.SelectedRows[0].Cells["ComId"].Value);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (ComNameTb.Text == "" || ComNoTb.Text == "" || ComAddrTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string ComName = ComNameTb.Text;
                    double ComNo = Convert.ToDouble(ComNoTb.Text);
                    string ComAddr = ComAddrTb.Text;
                    string Query = "Update CompanyTbl " +
                        "set ComName = @ComName, ComNo = @ComNo, ComAddr = @ComAddr " +
                        "where ComId = @ComId";
                    con.SetData(Query, new { ComName, ComNo, ComAddr, ComId = Key });
                    ShowCompany();

                    MessageBox.Show("Company Updated");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select a Column!!");
            }
            else
            {
                try
                {
                    string Query = "Delete from CompanyTbl where ComId=@ComId";
                    con.SetData(Query, new { ComId = Key });
                    ShowCompany();
                    MessageBox.Show("Company Deleted");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Medicinebtn_Click(object sender, EventArgs e)
        {
            Medicine obj = new Medicine();
            obj.Show();
            this.Close();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }

        private void CustBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Close();
        }

        private void BillingBtn_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Close();
        }

        private void DoctorBtn_Click(object sender, EventArgs e)
        {
            Doctor obj = new Doctor();
            obj.Show();
            this.Close();
        }
    }
}
