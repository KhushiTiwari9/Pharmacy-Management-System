﻿namespace Pharma_Project
{
    partial class Doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Doctor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DoctorBtn = new System.Windows.Forms.Label();
            this.BillingBtn = new System.Windows.Forms.Label();
            this.CustBtn = new System.Windows.Forms.Label();
            this.CompanyBtn = new System.Windows.Forms.Label();
            this.EmployeeBtn = new System.Windows.Forms.Label();
            this.Medicinebtn = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DoctorDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.DocAgeTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.DocNameTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.DocNoTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.DocAddrTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.DocDeleteBtn = new Guna.UI2.WinForms.Guna2Button();
            this.DocBackBtn = new Guna.UI2.WinForms.Guna2Button();
            this.DocAddBtn = new Guna.UI2.WinForms.Guna2Button();
            this.DocUpdateBtn = new Guna.UI2.WinForms.Guna2Button();
            this.DocDCb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DoctorDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.DoctorBtn);
            this.panel1.Controls.Add(this.BillingBtn);
            this.panel1.Controls.Add(this.CustBtn);
            this.panel1.Controls.Add(this.CompanyBtn);
            this.panel1.Controls.Add(this.EmployeeBtn);
            this.panel1.Controls.Add(this.Medicinebtn);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Location = new System.Drawing.Point(1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 687);
            this.panel1.TabIndex = 0;
            // 
            // DoctorBtn
            // 
            this.DoctorBtn.AutoSize = true;
            this.DoctorBtn.BackColor = System.Drawing.Color.Transparent;
            this.DoctorBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorBtn.ForeColor = System.Drawing.Color.Black;
            this.DoctorBtn.Location = new System.Drawing.Point(104, 547);
            this.DoctorBtn.Name = "DoctorBtn";
            this.DoctorBtn.Size = new System.Drawing.Size(193, 50);
            this.DoctorBtn.TabIndex = 38;
            this.DoctorBtn.Text = "DOCTOR";
            // 
            // BillingBtn
            // 
            this.BillingBtn.AutoSize = true;
            this.BillingBtn.BackColor = System.Drawing.Color.Transparent;
            this.BillingBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillingBtn.ForeColor = System.Drawing.Color.Black;
            this.BillingBtn.Location = new System.Drawing.Point(107, 617);
            this.BillingBtn.Name = "BillingBtn";
            this.BillingBtn.Size = new System.Drawing.Size(104, 50);
            this.BillingBtn.TabIndex = 37;
            this.BillingBtn.Text = "BILL";
            this.BillingBtn.Click += new System.EventHandler(this.BillingBtn_Click);
            // 
            // CustBtn
            // 
            this.CustBtn.AutoSize = true;
            this.CustBtn.BackColor = System.Drawing.Color.Transparent;
            this.CustBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustBtn.ForeColor = System.Drawing.Color.Black;
            this.CustBtn.Location = new System.Drawing.Point(104, 474);
            this.CustBtn.Name = "CustBtn";
            this.CustBtn.Size = new System.Drawing.Size(242, 50);
            this.CustBtn.TabIndex = 36;
            this.CustBtn.Text = "CUSTOMER";
            this.CustBtn.Click += new System.EventHandler(this.CustBtn_Click);
            // 
            // CompanyBtn
            // 
            this.CompanyBtn.AutoSize = true;
            this.CompanyBtn.BackColor = System.Drawing.Color.Transparent;
            this.CompanyBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyBtn.ForeColor = System.Drawing.Color.Black;
            this.CompanyBtn.Location = new System.Drawing.Point(107, 398);
            this.CompanyBtn.Name = "CompanyBtn";
            this.CompanyBtn.Size = new System.Drawing.Size(223, 50);
            this.CompanyBtn.TabIndex = 35;
            this.CompanyBtn.Text = "COMPANY";
            this.CompanyBtn.Click += new System.EventHandler(this.CompanyBtn_Click);
            // 
            // EmployeeBtn
            // 
            this.EmployeeBtn.AutoSize = true;
            this.EmployeeBtn.BackColor = System.Drawing.Color.Transparent;
            this.EmployeeBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeBtn.ForeColor = System.Drawing.Color.Black;
            this.EmployeeBtn.Location = new System.Drawing.Point(104, 327);
            this.EmployeeBtn.Name = "EmployeeBtn";
            this.EmployeeBtn.Size = new System.Drawing.Size(226, 50);
            this.EmployeeBtn.TabIndex = 34;
            this.EmployeeBtn.Text = "EMPLOYEE";
            this.EmployeeBtn.Click += new System.EventHandler(this.EmployeeBtn_Click);
            // 
            // Medicinebtn
            // 
            this.Medicinebtn.AutoSize = true;
            this.Medicinebtn.BackColor = System.Drawing.Color.Transparent;
            this.Medicinebtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medicinebtn.ForeColor = System.Drawing.Color.Black;
            this.Medicinebtn.Location = new System.Drawing.Point(104, 242);
            this.Medicinebtn.Name = "Medicinebtn";
            this.Medicinebtn.Size = new System.Drawing.Size(220, 50);
            this.Medicinebtn.TabIndex = 33;
            this.Medicinebtn.Text = "MEDICINE";
            this.Medicinebtn.Click += new System.EventHandler(this.Medicinebtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(131, 51);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(131, 112);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Samsung SVD_Medium_JP", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(510, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 84);
            this.label1.TabIndex = 3;
            this.label1.Text = "DOCTOR";
            // 
            // DoctorDGV
            // 
            this.DoctorDGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.DoctorDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DoctorDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DoctorDGV.ColumnHeadersHeight = 28;
            this.DoctorDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DoctorDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.DoctorDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DoctorDGV.Location = new System.Drawing.Point(910, -1);
            this.DoctorDGV.Name = "DoctorDGV";
            this.DoctorDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DoctorDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DoctorDGV.RowHeadersVisible = false;
            this.DoctorDGV.RowHeadersWidth = 51;
            this.DoctorDGV.RowTemplate.Height = 32;
            this.DoctorDGV.Size = new System.Drawing.Size(737, 686);
            this.DoctorDGV.TabIndex = 1;
            this.DoctorDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DoctorDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DoctorDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DoctorDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DoctorDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DoctorDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DoctorDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DoctorDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DoctorDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DoctorDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DoctorDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DoctorDGV.ThemeStyle.HeaderStyle.Height = 28;
            this.DoctorDGV.ThemeStyle.ReadOnly = false;
            this.DoctorDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DoctorDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DoctorDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DoctorDGV.ThemeStyle.RowsStyle.Height = 32;
            this.DoctorDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DoctorDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DoctorDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DoctorDGV_CellContentClick);
            // 
            // DocAgeTb
            // 
            this.DocAgeTb.BackColor = System.Drawing.Color.Wheat;
            this.DocAgeTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocAgeTb.DefaultText = "";
            this.DocAgeTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.DocAgeTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.DocAgeTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocAgeTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocAgeTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocAgeTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocAgeTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocAgeTb.Location = new System.Drawing.Point(708, 193);
            this.DocAgeTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DocAgeTb.Name = "DocAgeTb";
            this.DocAgeTb.PasswordChar = '\0';
            this.DocAgeTb.PlaceholderText = "Doctor Age";
            this.DocAgeTb.SelectedText = "";
            this.DocAgeTb.Size = new System.Drawing.Size(175, 47);
            this.DocAgeTb.TabIndex = 25;
            // 
            // DocNameTb
            // 
            this.DocNameTb.BackColor = System.Drawing.Color.Wheat;
            this.DocNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocNameTb.DefaultText = "";
            this.DocNameTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.DocNameTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.DocNameTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocNameTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocNameTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocNameTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocNameTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocNameTb.Location = new System.Drawing.Point(414, 193);
            this.DocNameTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DocNameTb.Name = "DocNameTb";
            this.DocNameTb.PasswordChar = '\0';
            this.DocNameTb.PlaceholderText = "Doctor Name";
            this.DocNameTb.SelectedText = "";
            this.DocNameTb.Size = new System.Drawing.Size(175, 47);
            this.DocNameTb.TabIndex = 24;
            // 
            // DocNoTb
            // 
            this.DocNoTb.BackColor = System.Drawing.Color.Wheat;
            this.DocNoTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocNoTb.DefaultText = "";
            this.DocNoTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.DocNoTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.DocNoTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocNoTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocNoTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocNoTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocNoTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocNoTb.Location = new System.Drawing.Point(414, 290);
            this.DocNoTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DocNoTb.Name = "DocNoTb";
            this.DocNoTb.PasswordChar = '\0';
            this.DocNoTb.PlaceholderText = "Doctor Number";
            this.DocNoTb.SelectedText = "";
            this.DocNoTb.Size = new System.Drawing.Size(175, 47);
            this.DocNoTb.TabIndex = 23;
            // 
            // DocAddrTb
            // 
            this.DocAddrTb.BackColor = System.Drawing.Color.Wheat;
            this.DocAddrTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DocAddrTb.DefaultText = "";
            this.DocAddrTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.DocAddrTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.DocAddrTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocAddrTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.DocAddrTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocAddrTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocAddrTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocAddrTb.Location = new System.Drawing.Point(708, 290);
            this.DocAddrTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DocAddrTb.Name = "DocAddrTb";
            this.DocAddrTb.PasswordChar = '\0';
            this.DocAddrTb.PlaceholderText = "Doctor Address";
            this.DocAddrTb.SelectedText = "";
            this.DocAddrTb.Size = new System.Drawing.Size(175, 47);
            this.DocAddrTb.TabIndex = 22;
            // 
            // DocDeleteBtn
            // 
            this.DocDeleteBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DocDeleteBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DocDeleteBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DocDeleteBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DocDeleteBtn.FillColor = System.Drawing.Color.White;
            this.DocDeleteBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocDeleteBtn.ForeColor = System.Drawing.Color.Teal;
            this.DocDeleteBtn.Location = new System.Drawing.Point(577, 601);
            this.DocDeleteBtn.Name = "DocDeleteBtn";
            this.DocDeleteBtn.Size = new System.Drawing.Size(145, 47);
            this.DocDeleteBtn.TabIndex = 21;
            this.DocDeleteBtn.Text = "Delete";
            this.DocDeleteBtn.Click += new System.EventHandler(this.DocDeleteBtn_Click);
            // 
            // DocBackBtn
            // 
            this.DocBackBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DocBackBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DocBackBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DocBackBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DocBackBtn.FillColor = System.Drawing.Color.White;
            this.DocBackBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocBackBtn.ForeColor = System.Drawing.Color.Teal;
            this.DocBackBtn.Location = new System.Drawing.Point(762, 486);
            this.DocBackBtn.Name = "DocBackBtn";
            this.DocBackBtn.Size = new System.Drawing.Size(121, 47);
            this.DocBackBtn.TabIndex = 20;
            this.DocBackBtn.Text = "Back";
            this.DocBackBtn.Click += new System.EventHandler(this.DocBackBtn_Click);
            // 
            // DocAddBtn
            // 
            this.DocAddBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DocAddBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DocAddBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DocAddBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DocAddBtn.FillColor = System.Drawing.Color.White;
            this.DocAddBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocAddBtn.ForeColor = System.Drawing.Color.Teal;
            this.DocAddBtn.Location = new System.Drawing.Point(414, 486);
            this.DocAddBtn.Name = "DocAddBtn";
            this.DocAddBtn.Size = new System.Drawing.Size(105, 47);
            this.DocAddBtn.TabIndex = 19;
            this.DocAddBtn.Text = "Add";
            this.DocAddBtn.Click += new System.EventHandler(this.DocAddBtn_Click_1);
            // 
            // DocUpdateBtn
            // 
            this.DocUpdateBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DocUpdateBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DocUpdateBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DocUpdateBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DocUpdateBtn.FillColor = System.Drawing.Color.White;
            this.DocUpdateBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocUpdateBtn.ForeColor = System.Drawing.Color.Teal;
            this.DocUpdateBtn.Location = new System.Drawing.Point(577, 486);
            this.DocUpdateBtn.Name = "DocUpdateBtn";
            this.DocUpdateBtn.Size = new System.Drawing.Size(145, 47);
            this.DocUpdateBtn.TabIndex = 18;
            this.DocUpdateBtn.Text = "Update";
            this.DocUpdateBtn.Click += new System.EventHandler(this.DocUpdateBtn_Click);
            // 
            // DocDCb
            // 
            this.DocDCb.BackColor = System.Drawing.Color.Transparent;
            this.DocDCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.DocDCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DocDCb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocDCb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.DocDCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.DocDCb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.DocDCb.ItemHeight = 30;
            this.DocDCb.Items.AddRange(new object[] {
            "MBBS",
            "BMS",
            "BHS",
            "BDS"});
            this.DocDCb.Location = new System.Drawing.Point(414, 378);
            this.DocDCb.Name = "DocDCb";
            this.DocDCb.Size = new System.Drawing.Size(236, 36);
            this.DocDCb.TabIndex = 26;
            // 
            // Doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1649, 686);
            this.Controls.Add(this.DocDCb);
            this.Controls.Add(this.DocAgeTb);
            this.Controls.Add(this.DocNameTb);
            this.Controls.Add(this.DocNoTb);
            this.Controls.Add(this.DocAddrTb);
            this.Controls.Add(this.DocDeleteBtn);
            this.Controls.Add(this.DocBackBtn);
            this.Controls.Add(this.DocAddBtn);
            this.Controls.Add(this.DocUpdateBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DoctorDGV);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Doctor";
            this.Text = "Doctor";
            this.Load += new System.EventHandler(this.Doctor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DoctorDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label BillingBtn;
        private System.Windows.Forms.Label CustBtn;
        private System.Windows.Forms.Label CompanyBtn;
        private System.Windows.Forms.Label EmployeeBtn;
        private System.Windows.Forms.Label Medicinebtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2DataGridView DoctorDGV;
        private Guna.UI2.WinForms.Guna2TextBox DocAgeTb;
        private Guna.UI2.WinForms.Guna2TextBox DocNameTb;
        private Guna.UI2.WinForms.Guna2TextBox DocNoTb;
        private Guna.UI2.WinForms.Guna2TextBox DocAddrTb;
        private Guna.UI2.WinForms.Guna2Button DocDeleteBtn;
        private Guna.UI2.WinForms.Guna2Button DocBackBtn;
        private Guna.UI2.WinForms.Guna2Button DocAddBtn;
        private Guna.UI2.WinForms.Guna2Button DocUpdateBtn;
        private Guna.UI2.WinForms.Guna2ComboBox DocDCb;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler1;
        private System.Windows.Forms.Label DoctorBtn;
    }
}