﻿namespace Pharma_Project
{
    partial class Medicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Medicine));
            this.MedicineDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DoctorBtn = new System.Windows.Forms.Label();
            this.BillingBtn = new System.Windows.Forms.Label();
            this.CustBtn = new System.Windows.Forms.Label();
            this.CompanyBtn = new System.Windows.Forms.Label();
            this.EmployeeBtn = new System.Windows.Forms.Label();
            this.Medicinebtn = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.MedNameTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.BackBtn = new Guna.UI2.WinForms.Guna2Button();
            this.DeleteBtn = new Guna.UI2.WinForms.Guna2Button();
            this.UpdateBtn = new Guna.UI2.WinForms.Guna2Button();
            this.AddBtn = new Guna.UI2.WinForms.Guna2Button();
            this.CompanyCb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.ExpDateTb = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.QtyTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.SpTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.BpTb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerBtn = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BillBtn = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.MedBtn = new System.Windows.Forms.Label();
            this.EmpBtn = new System.Windows.Forms.Label();
            this.CompBtn = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.ComBtn = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.MedicineDGV)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.ComBtn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MedicineDGV
            // 
            this.MedicineDGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.White;
            this.MedicineDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MedicineDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.MedicineDGV.ColumnHeadersHeight = 37;
            this.MedicineDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MedicineDGV.DefaultCellStyle = dataGridViewCellStyle15;
            this.MedicineDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MedicineDGV.Location = new System.Drawing.Point(885, 3);
            this.MedicineDGV.Name = "MedicineDGV";
            this.MedicineDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MedicineDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.MedicineDGV.RowHeadersVisible = false;
            this.MedicineDGV.RowHeadersWidth = 51;
            this.MedicineDGV.RowTemplate.Height = 27;
            this.MedicineDGV.Size = new System.Drawing.Size(674, 675);
            this.MedicineDGV.TabIndex = 1;
            this.MedicineDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.Salmon;
            this.MedicineDGV.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MedicineDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.MedicineDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MedicineDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.MedicineDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MedicineDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MedicineDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.MedicineDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.MedicineDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.MedicineDGV.ThemeStyle.HeaderStyle.Height = 37;
            this.MedicineDGV.ThemeStyle.ReadOnly = false;
            this.MedicineDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.MedicineDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.MedicineDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(59)))));
            this.MedicineDGV.ThemeStyle.RowsStyle.Height = 27;
            this.MedicineDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.MedicineDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MedicineDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MedicineDGV_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.MedicineDGV);
            this.panel1.Controls.Add(this.MedNameTb);
            this.panel1.Controls.Add(this.BackBtn);
            this.panel1.Controls.Add(this.DeleteBtn);
            this.panel1.Controls.Add(this.UpdateBtn);
            this.panel1.Controls.Add(this.AddBtn);
            this.panel1.Controls.Add(this.CompanyCb);
            this.panel1.Controls.Add(this.ExpDateTb);
            this.panel1.Controls.Add(this.QtyTb);
            this.panel1.Controls.Add(this.SpTb);
            this.panel1.Controls.Add(this.BpTb);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1560, 678);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.DoctorBtn);
            this.panel2.Controls.Add(this.BillingBtn);
            this.panel2.Controls.Add(this.CustBtn);
            this.panel2.Controls.Add(this.CompanyBtn);
            this.panel2.Controls.Add(this.EmployeeBtn);
            this.panel2.Controls.Add(this.Medicinebtn);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(369, 678);
            this.panel2.TabIndex = 26;
            // 
            // DoctorBtn
            // 
            this.DoctorBtn.AutoSize = true;
            this.DoctorBtn.BackColor = System.Drawing.Color.Transparent;
            this.DoctorBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorBtn.ForeColor = System.Drawing.Color.Black;
            this.DoctorBtn.Location = new System.Drawing.Point(105, 525);
            this.DoctorBtn.Name = "DoctorBtn";
            this.DoctorBtn.Size = new System.Drawing.Size(193, 50);
            this.DoctorBtn.TabIndex = 39;
            this.DoctorBtn.Text = "DOCTOR";
            this.DoctorBtn.Click += new System.EventHandler(this.DoctorBtn_Click);
            // 
            // BillingBtn
            // 
            this.BillingBtn.AutoSize = true;
            this.BillingBtn.BackColor = System.Drawing.Color.Transparent;
            this.BillingBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillingBtn.ForeColor = System.Drawing.Color.Black;
            this.BillingBtn.Location = new System.Drawing.Point(105, 593);
            this.BillingBtn.Name = "BillingBtn";
            this.BillingBtn.Size = new System.Drawing.Size(104, 50);
            this.BillingBtn.TabIndex = 31;
            this.BillingBtn.Text = "BILL";
            this.BillingBtn.Click += new System.EventHandler(this.BillingBtn_Click);
            // 
            // CustBtn
            // 
            this.CustBtn.AutoSize = true;
            this.CustBtn.BackColor = System.Drawing.Color.Transparent;
            this.CustBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustBtn.ForeColor = System.Drawing.Color.Black;
            this.CustBtn.Location = new System.Drawing.Point(105, 456);
            this.CustBtn.Name = "CustBtn";
            this.CustBtn.Size = new System.Drawing.Size(242, 50);
            this.CustBtn.TabIndex = 30;
            this.CustBtn.Text = "CUSTOMER";
            this.CustBtn.Click += new System.EventHandler(this.CustBtn_Click);
            // 
            // CompanyBtn
            // 
            this.CompanyBtn.AutoSize = true;
            this.CompanyBtn.BackColor = System.Drawing.Color.Transparent;
            this.CompanyBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyBtn.ForeColor = System.Drawing.Color.Black;
            this.CompanyBtn.Location = new System.Drawing.Point(105, 376);
            this.CompanyBtn.Name = "CompanyBtn";
            this.CompanyBtn.Size = new System.Drawing.Size(223, 50);
            this.CompanyBtn.TabIndex = 29;
            this.CompanyBtn.Text = "COMPANY";
            this.CompanyBtn.Click += new System.EventHandler(this.CompanyBtn_Click);
            // 
            // EmployeeBtn
            // 
            this.EmployeeBtn.AutoSize = true;
            this.EmployeeBtn.BackColor = System.Drawing.Color.Transparent;
            this.EmployeeBtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeBtn.ForeColor = System.Drawing.Color.Black;
            this.EmployeeBtn.Location = new System.Drawing.Point(105, 302);
            this.EmployeeBtn.Name = "EmployeeBtn";
            this.EmployeeBtn.Size = new System.Drawing.Size(226, 50);
            this.EmployeeBtn.TabIndex = 28;
            this.EmployeeBtn.Text = "EMPLOYEE";
            this.EmployeeBtn.Click += new System.EventHandler(this.EmployeeBtn_Click);
            // 
            // Medicinebtn
            // 
            this.Medicinebtn.AutoSize = true;
            this.Medicinebtn.BackColor = System.Drawing.Color.Transparent;
            this.Medicinebtn.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medicinebtn.ForeColor = System.Drawing.Color.Black;
            this.Medicinebtn.Location = new System.Drawing.Point(105, 213);
            this.Medicinebtn.Name = "Medicinebtn";
            this.Medicinebtn.Size = new System.Drawing.Size(220, 50);
            this.Medicinebtn.TabIndex = 27;
            this.Medicinebtn.Text = "MEDICINE";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(124, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(131, 112);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // MedNameTb
            // 
            this.MedNameTb.BackColor = System.Drawing.Color.Wheat;
            this.MedNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MedNameTb.DefaultText = "";
            this.MedNameTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.MedNameTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.MedNameTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MedNameTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.MedNameTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MedNameTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedNameTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.MedNameTb.Location = new System.Drawing.Point(425, 144);
            this.MedNameTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MedNameTb.Name = "MedNameTb";
            this.MedNameTb.PasswordChar = '\0';
            this.MedNameTb.PlaceholderText = "Medicine Name";
            this.MedNameTb.SelectedText = "";
            this.MedNameTb.Size = new System.Drawing.Size(159, 47);
            this.MedNameTb.TabIndex = 11;
            // 
            // BackBtn
            // 
            this.BackBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BackBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BackBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BackBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BackBtn.FillColor = System.Drawing.Color.White;
            this.BackBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.Color.Teal;
            this.BackBtn.Location = new System.Drawing.Point(754, 489);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(114, 47);
            this.BackBtn.TabIndex = 10;
            this.BackBtn.Text = "Back";
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DeleteBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DeleteBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DeleteBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DeleteBtn.FillColor = System.Drawing.Color.White;
            this.DeleteBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteBtn.ForeColor = System.Drawing.Color.Teal;
            this.DeleteBtn.Location = new System.Drawing.Point(569, 595);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(133, 47);
            this.DeleteBtn.TabIndex = 9;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.UpdateBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.UpdateBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.UpdateBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.UpdateBtn.FillColor = System.Drawing.Color.White;
            this.UpdateBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateBtn.ForeColor = System.Drawing.Color.Teal;
            this.UpdateBtn.Location = new System.Drawing.Point(569, 489);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(133, 47);
            this.UpdateBtn.TabIndex = 8;
            this.UpdateBtn.Text = "Update";
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AddBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AddBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AddBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AddBtn.FillColor = System.Drawing.Color.White;
            this.AddBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddBtn.ForeColor = System.Drawing.Color.Teal;
            this.AddBtn.Location = new System.Drawing.Point(412, 489);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(93, 47);
            this.AddBtn.TabIndex = 7;
            this.AddBtn.Text = "Add";
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // CompanyCb
            // 
            this.CompanyCb.BackColor = System.Drawing.Color.Transparent;
            this.CompanyCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CompanyCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CompanyCb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CompanyCb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CompanyCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.CompanyCb.ForeColor = System.Drawing.Color.Gray;
            this.CompanyCb.ItemHeight = 30;
            this.CompanyCb.Location = new System.Drawing.Point(425, 327);
            this.CompanyCb.Name = "CompanyCb";
            this.CompanyCb.Size = new System.Drawing.Size(211, 36);
            this.CompanyCb.TabIndex = 6;
            // 
            // ExpDateTb
            // 
            this.ExpDateTb.Checked = true;
            this.ExpDateTb.FillColor = System.Drawing.Color.DarkTurquoise;
            this.ExpDateTb.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExpDateTb.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.ExpDateTb.Location = new System.Drawing.Point(425, 225);
            this.ExpDateTb.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.ExpDateTb.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.ExpDateTb.Name = "ExpDateTb";
            this.ExpDateTb.Size = new System.Drawing.Size(248, 47);
            this.ExpDateTb.TabIndex = 5;
            this.ExpDateTb.Value = new System.DateTime(2024, 9, 9, 13, 34, 34, 124);
            // 
            // QtyTb
            // 
            this.QtyTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.QtyTb.DefaultText = "";
            this.QtyTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.QtyTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.QtyTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.QtyTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.QtyTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.QtyTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QtyTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.QtyTb.Location = new System.Drawing.Point(710, 316);
            this.QtyTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QtyTb.Name = "QtyTb";
            this.QtyTb.PasswordChar = '\0';
            this.QtyTb.PlaceholderText = "Quantity";
            this.QtyTb.SelectedText = "";
            this.QtyTb.Size = new System.Drawing.Size(158, 47);
            this.QtyTb.TabIndex = 4;
            // 
            // SpTb
            // 
            this.SpTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SpTb.DefaultText = "";
            this.SpTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SpTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SpTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SpTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SpTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SpTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SpTb.Location = new System.Drawing.Point(710, 225);
            this.SpTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SpTb.Name = "SpTb";
            this.SpTb.PasswordChar = '\0';
            this.SpTb.PlaceholderText = "Selling Price";
            this.SpTb.SelectedText = "";
            this.SpTb.Size = new System.Drawing.Size(158, 47);
            this.SpTb.TabIndex = 3;
            // 
            // BpTb
            // 
            this.BpTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BpTb.DefaultText = "";
            this.BpTb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BpTb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BpTb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BpTb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BpTb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BpTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BpTb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BpTb.Location = new System.Drawing.Point(710, 144);
            this.BpTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BpTb.Name = "BpTb";
            this.BpTb.PasswordChar = '\0';
            this.BpTb.PlaceholderText = "Buy Price";
            this.BpTb.SelectedText = "";
            this.BpTb.Size = new System.Drawing.Size(158, 47);
            this.BpTb.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Verdana", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(412, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(422, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Medicine Stock";
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.BackColor = System.Drawing.Color.Transparent;
            this.CustomerBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerBtn.ForeColor = System.Drawing.Color.Black;
            this.CustomerBtn.Location = new System.Drawing.Point(34, 455);
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(159, 38);
            this.CustomerBtn.TabIndex = 8;
            this.CustomerBtn.Text = "CUSTOMER";
            this.CustomerBtn.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BillBtn
            // 
            this.BillBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BillBtn.BackColor = System.Drawing.Color.Transparent;
            this.BillBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillBtn.ForeColor = System.Drawing.Color.Black;
            this.BillBtn.Location = new System.Drawing.Point(34, 522);
            this.BillBtn.Name = "BillBtn";
            this.BillBtn.Size = new System.Drawing.Size(60, 38);
            this.BillBtn.TabIndex = 6;
            this.BillBtn.Text = "BILL";
            this.BillBtn.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MedBtn
            // 
            this.MedBtn.AutoSize = true;
            this.MedBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedBtn.ForeColor = System.Drawing.Color.Black;
            this.MedBtn.Location = new System.Drawing.Point(28, 240);
            this.MedBtn.Name = "MedBtn";
            this.MedBtn.Size = new System.Drawing.Size(155, 38);
            this.MedBtn.TabIndex = 9;
            this.MedBtn.Text = "Medicine";
            // 
            // EmpBtn
            // 
            this.EmpBtn.AutoSize = true;
            this.EmpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpBtn.Location = new System.Drawing.Point(27, 313);
            this.EmpBtn.Name = "EmpBtn";
            this.EmpBtn.Size = new System.Drawing.Size(170, 38);
            this.EmpBtn.TabIndex = 10;
            this.EmpBtn.Text = "Employee";
            // 
            // CompBtn
            // 
            this.CompBtn.AutoSize = true;
            this.CompBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompBtn.ForeColor = System.Drawing.Color.Black;
            this.CompBtn.Location = new System.Drawing.Point(31, 385);
            this.CompBtn.Name = "CompBtn";
            this.CompBtn.Size = new System.Drawing.Size(164, 38);
            this.CompBtn.TabIndex = 11;
            this.CompBtn.Text = "Company";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(31, 385);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(162, 39);
            this.label.TabIndex = 11;
            this.label.Text = "Medicine";
            // 
            // ComBtn
            // 
            this.ComBtn.BackColor = System.Drawing.Color.White;
            this.ComBtn.Controls.Add(this.CompBtn);
            this.ComBtn.Controls.Add(this.EmpBtn);
            this.ComBtn.Controls.Add(this.MedBtn);
            this.ComBtn.Controls.Add(this.CustomerBtn);
            this.ComBtn.Controls.Add(this.BillBtn);
            this.ComBtn.Controls.Add(this.pictureBox1);
            this.ComBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.ComBtn.Location = new System.Drawing.Point(0, 0);
            this.ComBtn.Name = "ComBtn";
            this.ComBtn.Size = new System.Drawing.Size(334, 678);
            this.ComBtn.TabIndex = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(99, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(131, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1558, 678);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(59)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Medicine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Medicine";
            ((System.ComponentModel.ISupportInitialize)(this.MedicineDGV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ComBtn.ResumeLayout(false);
            this.ComBtn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox CompanyCb;
        private Guna.UI2.WinForms.Guna2DateTimePicker ExpDateTb;
        private Guna.UI2.WinForms.Guna2TextBox QtyTb;
        private Guna.UI2.WinForms.Guna2TextBox SpTb;
        private Guna.UI2.WinForms.Guna2TextBox BpTb;
        private Guna.UI2.WinForms.Guna2Button BackBtn;
        private Guna.UI2.WinForms.Guna2Button DeleteBtn;
        private Guna.UI2.WinForms.Guna2Button UpdateBtn;
        private Guna.UI2.WinForms.Guna2Button AddBtn;
        private Guna.UI2.WinForms.Guna2DataGridView MedicineDGV;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler1;
        private Guna.UI2.WinForms.Guna2TextBox MedNameTb;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler2;
        private Guna.UI2.WinForms.Guna2DataGridViewStyler guna2DataGridViewStyler3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel BillBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel CustomerBtn;
        private System.Windows.Forms.Label MedBtn;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label EmpBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label BillingBtn;
        private System.Windows.Forms.Label CustBtn;
        private System.Windows.Forms.Label CompanyBtn;
        private System.Windows.Forms.Label EmployeeBtn;
        private System.Windows.Forms.Label Medicinebtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label CompBtn;
        private System.Windows.Forms.Panel ComBtn;
        private System.Windows.Forms.Label DoctorBtn;
    }
}