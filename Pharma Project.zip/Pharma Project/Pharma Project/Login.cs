﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Login : Form
    {
        string Username = "Health";
        string Password = "Medicine";
        public Login()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, EventArgs e)
        {
            string EnteredUsername = UsernameTb.Text;
            string EnteredPassword = PasswordTb.Text;

            if (EnteredUsername == Username && EnteredPassword == Password)
            {
                MessageBox.Show("Login Success!! ");
                Medicine obj = new Medicine();
                obj.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Wrong Username or Password ");
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
    

