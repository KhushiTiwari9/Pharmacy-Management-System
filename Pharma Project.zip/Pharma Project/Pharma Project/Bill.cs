﻿using Pharma_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Bill : Form
    {
        Functions con;
        public Bill()
        {
            InitializeComponent();
            InitializeBillDGV();
            con = new Functions();
            ShowDetails();
           
            CustomerIdTb.KeyDown += CustomerIdTb_KeyDown;
            MedicineIdTb.KeyDown += MedicineIdTb_KeyDown;
        }

        private void ShowDetails()
        {
            string MedQuery = "SELECT MId, MedName, SPrice FROM MedicineTbl";
            MedicineDGV.DataSource = con.GetData(MedQuery);

            string customerQuery = "SELECT CustomerId, CustomerName FROM CustomerTbl";
            CustDGV.DataSource = con.GetData(customerQuery);

        }
        private void CustomerIdTb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (int.TryParse(CustomerIdTb.Text, out int CId))
                {
                    PopulateCustomerDetails(CId);
                }
                else
                {
                    MessageBox.Show("Invalid Customer ID format");
                }
            }

        }

        private void MedicineIdTb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (int.TryParse(MedicineIdTb.Text, out int MedicineId))
                {
                    PopulateMedicineDetails(MedicineId);
                }
                else
                {
                    MessageBox.Show("Invalid Medicine ID format");
                }
            }
        }

        private void PopulateCustomerDetails(int CId)
        {
            try
            {
                string Query = "select CustomerName from CustomerTbl Where CustomerId= @CustomerId";
                DataTable dt = con.GetData(Query, new { CustomerId = CId });
                if (dt != null && dt.Rows.Count > 0)
                {
                    CustomerNameTb.Text = dt.Rows[0]["CustomerName"].ToString();
                }
                else
                {
                    MessageBox.Show("Customer Not Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Fetching Customer Details" + ex.Message);
            }
        }
        private void PopulateMedicineDetails(int MedicineId)
        {
            try
            {
                string Query = "select MedName, SPrice from MedicineTbl Where MId= @MId";
                DataTable dt = con.GetData(Query, new { MId = MedicineId });
                if (dt != null && dt.Rows.Count > 0)
                {
                    MedNameTb.Text = dt.Rows[0]["MedName"].ToString();
                    PriceTb.Text = dt.Rows[0]["SPrice"].ToString();
                }
                else
                {
                    MessageBox.Show("Medicine Not Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Fetching Medicine Details" + ex.Message);
            }
        }
        private void InitializeBillDGV()
        {
            BillDGV.Columns.Clear();
            BillDGV.Columns.Add("BillId", "Bill Id");
            BillDGV.Columns.Add("MedicineId", "Medicine ID");
            BillDGV.Columns.Add("MedName", "Medicine Name");
            BillDGV.Columns.Add("SPrice", "Price");
            BillDGV.Columns.Add("Quantity", "Quantity");
            BillDGV.Columns.Add("TotalPrice", "Total Price");

            BillDGV.AllowUserToAddRows = false;
        }
        private void MedBtn_Click(object sender, EventArgs e)
        {
            Medicine obj = new Medicine();
            obj.Show();
            this.Close();
        }

        private void EmpBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }

        private void ComBtn_Click(object sender, EventArgs e)
        {
            Company obj = new Company();
            obj.Show();
            this.Close();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(MedNameTb.Text) || string.IsNullOrWhiteSpace(QtyTb.Text))
            {
                MessageBox.Show("Missing Medicine information");
                return;
            }

            if (string.IsNullOrWhiteSpace(MedicineIdTb.Text) || !int.TryParse(MedicineIdTb.Text, out int MedicineId))
            {
                MessageBox.Show("Invalid or missing Medicine ID.");
                return;
            }

            if (!int.TryParse(QtyTb.Text, out int Quantity))
            {
                MessageBox.Show("Invalid Quantity format");
                return;
            }

            if (!decimal.TryParse(PriceTb.Text, out decimal SPrice))
            {
                MessageBox.Show("Invalid Price format");
                return;
            }
            try
            {
                string StockQuery = "Select Stock from MedicineTbl where MId=@MId";
                DataTable Stockdata = con.GetData(StockQuery, new { MId = MedicineId });
                if (Stockdata != null && Stockdata.Rows.Count > 0)
                {
                    int availableStock = Convert.ToInt32(Stockdata.Rows[0]["Stock"]);

                    if (Quantity > availableStock)
                    {
                        MessageBox.Show($"Stock is Unavailable.  Available Stock: {availableStock}");
                        return;
                    }

                    decimal Total = Quantity * SPrice;
                    int billId = BillDGV.Rows.Count + 1;

                    if (MedicineId > 0 && !string.IsNullOrWhiteSpace(MedNameTb.Text) && SPrice > 0 && Quantity > 0)
                    {

                        MessageBox.Show($"Adding to cart: BillId: {billId}, ProductId: {MedicineId}, Name: {MedNameTb.Text}, SPrice: {PriceTb.Text}, Quantity: {QtyTb.Text}, Total: {Total}");
                        BillDGV.Rows.Add(billId, MedicineId, MedNameTb.Text, SPrice, Quantity, Total.ToString("0.00"));
                        CalculateTotalBill();
                    }
                    else
                    {
                        MessageBox.Show("Error: Missing or invalid medicine details.");
                    }
                }
                else
                {
                    MessageBox.Show("Medicine not found in inventory");
                }

            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values for Quantity and Price");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error Adding to Purchased Items"+ex.Message);
            }
        }
        private void CalculateTotalBill()
        {
            decimal TotalBill = 0;

            foreach (DataGridViewRow row in BillDGV.Rows)
            {
                if (row.Cells["TotalPrice"].Value != null)
                {
                    TotalBill += Convert.ToDecimal(row.Cells["TotalPrice"].Value);
                }
                TotalBillTb.Text = TotalBill.ToString("0.00");
            }
        }
        private void ResetForm()
        {
            CustomerIdTb.Text = "";
            CustomerNameTb.Text = "";
            MedicineIdTb.Text = "";
            MedNameTb.Text = "";
            PriceTb.Text = "";
            QtyTb.Text = "";
            TotalBillTb.Text = "";
        }

        private void GenerateBillBtn_Click_1(object sender, EventArgs e)
        { 
            if (string.IsNullOrWhiteSpace(CustomerIdTb.Text) || BillDGV.Rows.Count == 0)
            {
                MessageBox.Show("Incomplete Bill Details");
                return;
            }

            try
            {
                int customerId = Convert.ToInt32(CustomerIdTb.Text);

                foreach (DataGridViewRow row in BillDGV.Rows)
                {
                    Console.WriteLine($"Row Index: {row.Index}, MedicineId: {row.Cells["MedicineId"].Value}, MedName: {row.Cells["MedName"].Value}, SPrice: {row.Cells["SPrice"].Value}, Quantity: {row.Cells["Quantity"].Value}, TotalPrice: {row.Cells["TotalPrice"].Value}");
                }
                foreach (DataGridViewRow row in BillDGV.Rows)
                {
                    if (row.Cells["MedicineId"].Value == null || string.IsNullOrWhiteSpace(row.Cells["MedicineId"].Value.ToString()))
                    {
                        MessageBox.Show($"MedicineId is missing in row {row.Index + 1}. Please check your cart.");
                        return;

                    }
                   
                        int medicineId = Convert.ToInt32(row.Cells["MedicineId"].Value);
                        int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                        decimal totalPrice = Convert.ToDecimal(row.Cells["TotalPrice"].Value);

                        
                        string Query = "Insert into BillTbl(CustomerId, MedicineId, Quantity, TotalPrice, BillDate) " +
                            "Values (@CustomerId, @MedicineId, @Quantity, @TotalPrice, @BillDate) ";
                       
                            con.SetData(Query, new
                            {
                                CustomerId = customerId,
                                MedicineId = medicineId,
                                Quantity = quantity,
                                TotalPrice = totalPrice,
                                BillDate = DateTime.Now
                            });
                            string updatestockquery = "UPDATE MedicineTbl SET Stock = Stock - @Quantity WHERE MId = @MId";
                            con.SetData(updatestockquery, new { Quantity = quantity, MId = medicineId });                      
                }
                MessageBox.Show("Bill Generated successfully !!");
                PrintBill();

                BillDGV.Rows.Clear();
                ResetForm();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error generating Bill: " + ex.Message);
            }
        }

        private void Medicinebtn_Click(object sender, EventArgs e)
        {
            Medicine obj = new Medicine();
            obj.Show();
            this.Close();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }

        private void CompanyBtn_Click(object sender, EventArgs e)
        {
            Company obj = new Company();
            obj.Show();
            this.Close();
        }

        private void CustBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Close();
        }

        private void DoctorBtn_Click(object sender, EventArgs e)
        {
            Doctor obj = new Doctor();
            obj.Show();
            this.Close();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
                try
                {
                    string CId1 = CustomerIdTb.Text;

                    string query = @"
                                SELECT b.BillId, b.CustomerId, b.MedicineId, b.Quantity, b.TotalPrice, b.BillDate, 
                                 c.CustomerName, m.MedName
                                FROM BillTbl b
                                JOIN CustomerTbl c ON b.CustomerId = c.CustomerId
                                JOIN MedicineTbl m ON b.MedicineId = m.MId
                                WHERE b.CustomerId = @CustomerId";
                    DataTable dt = con.GetData(query, new { CustomerId = CId1 });

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        int Bid = Convert.ToInt32(dt.Rows[0]["BillId"]);
                        int Cid = Convert.ToInt32(dt.Rows[0]["CustomerId"]);
                        string customerName = dt.Rows[0]["CustomerName"].ToString();
                        string medicineName = dt.Rows[0]["MedName"].ToString();
                        DateTime date = Convert.ToDateTime(dt.Rows[0]["BillDate"]);
                        string MedicineId = dt.Rows[0]["MedicineId"].ToString();
                        int qty = Convert.ToInt32(dt.Rows[0]["Quantity"]);
                        decimal total = Convert.ToDecimal(dt.Rows[0]["TotalPrice"]);

                        e.Graphics.DrawString("----- || JayHind pharmaceuticals || -----", new Font("Comic Sans MS", 22, FontStyle.Bold), Brushes.LightCoral, new Point(100, 10));
                        e.Graphics.DrawString($"Date: {date}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(120, 135));
                        e.Graphics.DrawString($"Bill Id: {Bid}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(120, 185));
                        e.Graphics.DrawString($"Customer Id: {Cid}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(195, 270));
                        e.Graphics.DrawString($"Customer Id: {medicineName}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(195, 270));
                        e.Graphics.DrawString($"Medicine Id: {MedicineId}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(220, 430));
                        e.Graphics.DrawString($"Customer Id: {customerName}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(195, 270));
                        e.Graphics.DrawString($"Quantity: {qty}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(260, 510));
                        e.Graphics.DrawString($"Total Amount: {total:C}", new Font("Comic Sans MS", 18, FontStyle.Bold), Brushes.Black, new Point(545, 610));
                        e.Graphics.DrawString("** THANK YOU **", new Font("Comic Sans MS", 22, FontStyle.Bold), Brushes.Black, new Point(220, 850));
                    }
                    else
                    {
                        MessageBox.Show("No billing information found for the customer.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error printing invoice: " + ex.Message);
                }
        }

        private void PrintBill()
        {
            try
            {
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while printing: " + ex.Message);
            }
        }
    }
}
