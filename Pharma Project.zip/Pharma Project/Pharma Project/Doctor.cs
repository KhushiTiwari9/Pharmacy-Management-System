﻿using Pharma_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Doctor : Form
    {
        Functions con;
        int Key;


        public Doctor()
        {
            InitializeComponent();
            con = new Functions();
            ShowDoctor();
        }
        private void ShowDoctor()
        {
            string Query = "select * from DoctorTbl";
            DoctorDGV.DataSource = con.GetData(Query);
        }
        private void ResetColumns()
        {
            DocNameTb.Text = "";
            DocAgeTb.Text = "";
            DocNoTb.Text = "";
            DocAddrTb.Text = "";
            DocDCb.Text = "";
            Key = 0;
        }


        private void DoctorDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (DoctorDGV.SelectedRows.Count > 0)
                {
                    DocNameTb.Text = DoctorDGV.SelectedRows[0].Cells["DocName"].Value.ToString();
                    DocAgeTb.Text = DoctorDGV.SelectedRows[0].Cells["DocAge"].Value.ToString();
                    DocNoTb.Text = DoctorDGV.SelectedRows[0].Cells["DocNo"].Value.ToString();
                    DocDCb.Text = DoctorDGV.Text = DoctorDGV.SelectedRows[0].Cells["DocDegree"].Value.ToString();
                    DocAddrTb.Text = DoctorDGV.SelectedRows[0].Cells["DocAddr"].Value.ToString();

                    Key = Convert.ToInt32(DoctorDGV.SelectedRows[0].Cells["DocId"].Value);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DocUpdateBtn_Click(object sender, EventArgs e)
        {
            if (DocNameTb.Text == "" || DocAgeTb.Text == "" || DocNoTb.Text == "" || DocAddrTb.Text == "" || DocDCb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string DocName = DocNameTb.Text;
                    int DocAge = Convert.ToInt32(DocAgeTb.Text);
                    string DocNo = DocNoTb.Text;
                    string DocDegree = DocDCb.SelectedItem.ToString();
                    string DocAddr = DocAddrTb.Text;
                    string Query = "Update DoctorTbl " +
                        "Set DocName=@DocName,DocAge=@DocAge, DocNo=@DocNo,DocDegree=@DocDegree, DocAddr =@DocAddr "+
                        "where DocId=@DocId ";
                    con.SetData(Query, new { DocName, DocAge, DocNo, DocDegree, DocAddr, DocId = Key});

                    ShowDoctor();

                    MessageBox.Show("Doctor Updated");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void DocDeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select a Column!!");
            }
            else
            {
                try
                {
                    string Query = "Delete from DoctorTbl where DocId=@DocId";
                    con.SetData(Query, new { DocId = Key });

                    ShowDoctor();

                    MessageBox.Show("Doctor Deleted");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void DocBackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Medicinebtn_Click(object sender, EventArgs e)
        {
            Medicine obj = new Medicine();
            obj.Show();
            this.Close();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }

        private void CompanyBtn_Click(object sender, EventArgs e)
        {
            Company obj = new Company();
            obj.Show();
            this.Close();
        }

        private void CustBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Close();
        }

        private void BillingBtn_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Close();
        }

        private void Doctor_Load(object sender, EventArgs e)
        {

        }

        private void DocAddBtn_Click_1(object sender, EventArgs e)
        {
            if (DocNameTb.Text == "" || DocAgeTb.Text == "" || DocNoTb.Text == "" || DocAddrTb.Text == "" || DocDCb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string DocName = DocNameTb.Text;
                    string DocAge = DocAgeTb.Text;
                    string DocNo = DocNoTb.Text;
                    string DocDegree = DocDCb.SelectedItem.ToString();
                    string DocAddr = DocAddrTb.Text;
                    string Query = "Insert into DoctorTbl (DocName,DocAge, DocNo, DocDegree,DocAddr)" +
                        " values(@DocName,@DocAge, @DocNo, @DocDegree,@DocAddr)";
                    con.SetData(Query, new { DocName, DocAge, DocNo, DocDegree, DocAddr });

                    ShowDoctor();

                    MessageBox.Show("Doctor Added");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }
    }
}




