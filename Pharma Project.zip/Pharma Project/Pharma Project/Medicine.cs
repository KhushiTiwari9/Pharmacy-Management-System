﻿using Pharma_Project;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Medicine : Form
    {
        Functions con;
        public Medicine()
        {
            InitializeComponent();
            con = new Functions();
            ShowMedicine();
            PopulateCompanyComboBox();
        }
        private void ShowMedicine()
        {
            string Query = "select * from MedicineTbl";
            Console.WriteLine(Query);
            MedicineDGV.DataSource = con.GetData(Query);
        }

        private void ResetColumns()
        {
            MedNameTb.Text = "";
            BpTb.Text = "";
            SpTb.Text = "";
            QtyTb.Text = "";
            ExpDateTb.Text = "";
            CompanyCb.Text = "";
            Key = 0;
        }
        private void PopulateCompanyComboBox()
        {
            try
            {
                string Query = "SELECT ComId, ComName FROM CompanyTbl";
                DataTable dt = con.GetData(Query);

                if (dt != null && dt.Rows.Count > 0)
                {
                    CompanyCb.DataSource = dt;
                    CompanyCb.DisplayMember = "ComName";
                    CompanyCb.ValueMember = "ComId";
                }
                else
                {
                    CompanyCb.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error populating Company combo box: " + ex.Message);
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (MedNameTb.Text == "" || BpTb.Text == "" || SpTb.Text == "" || QtyTb.Text == "" || CompanyCb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {

                    string MedName = MedNameTb.Text;
                    int BPrice = Convert.ToInt32(BpTb.Text);
                    int SPrice = Convert.ToInt32(SpTb.Text);
                    int Stock = Convert.ToInt32(QtyTb.Text);
                    string ExpDate = ExpDateTb.Value.Date.ToString("yyyy-MM-dd");
                    int Company = (int)CompanyCb.SelectedValue;
                    string Query = "insert into MedicineTbl ( MedName,  BPrice, SPrice, Stock, ExpDate, Company ) " +
                                "values (@MedName, @BPrice, @SPrice, @Stock, @ExpDate, @Company)";

                    con.SetData(Query, new { MedName, BPrice, SPrice, Stock, ExpDate, Company });
                    ShowMedicine();
                    MessageBox.Show("Medicine Added");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
        }
        int Key = 0;

        private void MedicineDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MedNameTb.Text = MedicineDGV.SelectedRows[0].Cells["MedName"].Value.ToString();
            BpTb.Text = MedicineDGV.SelectedRows[0].Cells["BPrice"].Value.ToString();
            SpTb.Text = MedicineDGV.SelectedRows[0].Cells["SPrice"].Value.ToString();
            QtyTb.Text = MedicineDGV.SelectedRows[0].Cells["Stock"].Value.ToString();
            ExpDateTb.Text = MedicineDGV.SelectedRows[0].Cells["ExpDate"].Value.ToString();
            CompanyCb.Text = MedicineDGV.SelectedRows[0].Cells["Company"].Value.ToString();
            if (MedNameTb.Text == " ")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(MedicineDGV.SelectedRows[0].Cells[0].Value);
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (MedNameTb.Text == "" || MedNameTb.Text == "" || BpTb.Text == "" || SpTb.Text == "" || QtyTb.Text == "" || CompanyCb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string MedName = MedNameTb.Text;
                    int BPrice = Convert.ToInt32(BpTb.Text);
                    int SPrice = Convert.ToInt32(SpTb.Text);
                    int Stock = Convert.ToInt32(QtyTb.Text);
                    string ExpDate = ExpDateTb.Value.Date.ToString("yyyy-MM-dd");
                    int Company = (int)CompanyCb.SelectedValue;
                    string Query = "Update MedicineTbl " +
                        "set MedName=@MedName,  BPrice=@BPrice, SPrice=@SPrice, Stock=@Stock, ExpDate=@ExpDate, Company=@Company " +
                        "where MId=@MId";
                    con.SetData(Query, new { MedName, BPrice, SPrice, Stock, ExpDate, Company, MId = Key });
                    ShowMedicine();
                    MessageBox.Show("Medicine Updated");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }

        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select a Column!!");
            }
            else
            {
                try
                {
                    string Query = "Delete from MedicineTbl where MId=@MId";
                    con.SetData(Query, new { MId = Key });

                    ShowMedicine();

                    MessageBox.Show("Medicine Deleted");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }

        private void CompanyBtn_Click(object sender, EventArgs e)
        {
            Company obj = new Company();
            obj.Show();
            this.Close();
        }

        private void CustBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Close();
        }

        private void BillingBtn_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Close();
        }

        private void DoctorBtn_Click(object sender, EventArgs e)
        {
            Doctor obj=new Doctor();
            obj.Show();
            this.Close();   
        }

        
    }
}

