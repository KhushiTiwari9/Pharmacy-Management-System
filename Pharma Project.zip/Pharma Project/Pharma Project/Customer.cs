﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharma_Project
{
    public partial class Customer : Form
    {
        Functions con;
        int Key;
        public Customer()
        {
            InitializeComponent();
            con = new Functions();
            ShowCustomer();
        }
        private void ShowCustomer()
        {
            string Query = "select * from CustomerTbl";
            CustomerDGV.DataSource = con.GetData(Query);
        }
        private void ResetColumns()
        {
            CustNameTb.Text = "";
            CustAgeTb.Text = "";
            CustNoTb.Text = "";
            CustAddrTb.Text = "";
            Key = 0;
        }

        private void CustAddBtn_Click(object sender, EventArgs e)
        {
            if (CustNameTb.Text == "" || CustAgeTb.Text == "" || CustNoTb.Text == "" || CustAddrTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string CustomerName = CustNameTb.Text;
                    int CustomerAge = Convert.ToInt32(CustAgeTb.Text);
                    string CustomerNo = CustNoTb.Text;
                    string CustomerAddr = CustAddrTb.Text;
                    string Query = "Insert into CustomerTbl (CustomerName,CustomerAge, CustomerNo, CustomerAddr)" +
                        " values(@CustomerName,@CustomerAge, @CustomerNo, @CustomerAddr)";
                    con.SetData(Query, new { CustomerName, CustomerAge, CustomerNo, CustomerAddr });

                    ShowCustomer();

                    MessageBox.Show("Customer Added");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (CustomerDGV.SelectedRows.Count > 0)
                {
                    CustNameTb.Text = CustomerDGV.SelectedRows[0].Cells["CustomerName"].Value.ToString();
                    CustAgeTb.Text = CustomerDGV.SelectedRows[0].Cells["CustomerAge"].Value.ToString();
                    CustNoTb.Text = CustomerDGV.SelectedRows[0].Cells["CustomerNo"].Value.ToString();
                    CustAddrTb.Text = CustomerDGV.SelectedRows[0].Cells["CustomerAddr"].Value.ToString();

                    Key = Convert.ToInt32(CustomerDGV.SelectedRows[0].Cells["CustomerId"].Value);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CustUpdateBtn_Click(object sender, EventArgs e)
        {
            if (CustNameTb.Text == "" || CustAgeTb.Text == "" || CustNoTb.Text == "" || CustAddrTb.Text == "")
            {
                MessageBox.Show("Missing Data !!");
            }
            else
            {
                try
                {
                    string CustomerName = CustNameTb.Text;
                    int CustomerAge = Convert.ToInt32(CustAgeTb.Text);
                    string CustomerNo = CustNoTb.Text;
                    string CustomerAddr = CustAddrTb.Text;
                    string Query = "Update CustomerTbl " +
                        "set CustomerName = @CustomerName,CustomerAge=@CustomerAge, CustomerNo=@CustomerNo,CustomerAddr=@CustomerAddr " +
                        "where CustomerId=@CustomerId";
                    con.SetData(Query, new { CustomerName, CustomerAge, CustomerNo, CustomerAddr, CustomerId=Key });

                    ShowCustomer();

                    MessageBox.Show("Customer Updated");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void CustDeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select a Column!!");
            }
            else
            {
                try
                {
                    string Query = "Delete from CustomerTbl where CustomerId=@CustomerId";
                    con.SetData(Query, new { CustomerId = Key });

                    ShowCustomer();

                    MessageBox.Show("Customer Deleted");
                    ResetColumns();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Medicinebtn_Click(object sender, EventArgs e)
        {
            Medicine obj = new Medicine();
            obj.Show();
            this.Close();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employees obj = new Employees();
            obj.Show();
            this.Close();
        }
        private void BillingBtn_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Close();
        }

        private void CompanyBtn_Click(object sender, EventArgs e)
        {
            Company obj = new Company();
            obj.Show();
            this.Close();
        }

        private void CustBackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DoctorBtn_Click(object sender, EventArgs e)
        {
            Doctor obj = new Doctor();
            obj.Show();
            this.Close();
        }
    }
}
