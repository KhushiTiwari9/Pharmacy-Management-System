﻿CREATE TABLE [dbo].[MedicineTbl] (
    [MId]         INT           IDENTITY (500, 1) NOT NULL,
    [MedName]        VARCHAR (50)  NOT NULL,
    [BPrice]    INT           NOT NULL,
    [SPrice]       INT           NOT NULL,
    [Quantity]       INT           NOT NULL,
    [ExpDate] DATE NOT NULL,
    [Company] VARCHAR(50) NOT NULL,
    PRIMARY KEY CLUSTERED ([MId] ASC)
);